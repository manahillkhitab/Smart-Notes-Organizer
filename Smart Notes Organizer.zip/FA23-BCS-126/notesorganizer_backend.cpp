#include <iostream>
#include <string>
#include <unordered_map>
#include <fstream>
#include <stack>
#include <vector>
#include <queue>
#include <algorithm>
#include <cctype>
#include <chrono>
#include <iomanip>
#include <sstream>
#include <memory>
using namespace std;

// ---------- Utility Functions ----------
string toLower(const string& s) {
    string t = s;
    transform(t.begin(), t.end(), t.begin(), ::tolower);
    return t;
}
bool isValidDate(const string& date) {
    if (date.size() != 10) return false;
    if (date[2] != '-' || date[5] != '-') return false;
    int d, m, y;
    try {
        d = stoi(date.substr(0,2));
        m = stoi(date.substr(3,2));
        y = stoi(date.substr(6,4));
    } catch (...) { return false; }
    if (d < 1 || d > 31 || m < 1 || m > 12 || y < 1900) return false;
    return true;
}
int dateToInt(const string& date) {
    return stoi(date.substr(6,4)) * 10000 + stoi(date.substr(3,2)) * 100 + stoi(date.substr(0,2));
}
string getCurrentTimestamp() {
    auto now = chrono::system_clock::now();
    time_t now_c = chrono::system_clock::to_time_t(now);
    tm* parts = localtime(&now_c);
    char buf[20];
    strftime(buf, sizeof(buf), "%d-%m-%Y %H:%M", parts);
    return string(buf);
}
vector<string> splitWords(const string& text) {
    vector<string> words;
    stringstream ss(text);
    string word;
    while (ss >> word) {
        word.erase(remove_if(word.begin(), word.end(), [](char c){return !isalnum(c);}), word.end());
        if (!word.empty()) words.push_back(toLower(word));
    }
    return words;
}
bool getIntInput(const string& prompt, int& value, int minVal = INT_MIN, int maxVal = INT_MAX, bool allowBlank = false) {
    string line;
    while (true) {
        cout << prompt;
        getline(cin, line);
        if (allowBlank && line.empty()) return false;
        try {
            size_t idx;
            value = stoi(line, &idx);
            if (idx != line.size())
                throw invalid_argument("Non-integer input");
            if (value < minVal || value > maxVal)
                throw out_of_range("Out of range");
            return true;
        } catch (...) {
            cout << "Invalid input. Please enter a valid number";
            if (minVal != INT_MIN && maxVal != INT_MAX)
                cout << " (" << minVal << "-" << maxVal << ")";
            cout << ".\n";
        }
    }
}

// ---------- Data Structures ----------
struct Note {
    int id;
    string title, content, dateCreated, reminder;
    int priority;
    weak_ptr<Note> prev;
    weak_ptr<Note> next;
    Note(int _id, string _title, string _content, int _priority, string _date, string _reminder = "")
        : id(_id), title(_title), content(_content), priority(_priority),
          dateCreated(_date), reminder(_reminder) {}
    Note(const Note& other)
        : id(other.id), title(other.title), content(other.content),
          priority(other.priority), dateCreated(other.dateCreated), reminder(other.reminder) {}
};

enum ActionType { ADD, DELETE, EDIT };

struct Action {
    ActionType type;
    unique_ptr<Note> noteCopy;
    int noteId;
    unique_ptr<Note> noteAfterEdit;
    Action(ActionType t, unique_ptr<Note> n, int id, unique_ptr<Note> afterEdit = nullptr)
        : type(t), noteCopy(move(n)), noteId(id), noteAfterEdit(move(afterEdit)) {}
};

struct HistoryEntry {
    string action;
    Note noteSnapshot;
    string timestamp;
};

struct PriorityCompare {
    bool operator()(const shared_ptr<Note>& a, const shared_ptr<Note>& b) {
        return a->priority > b->priority;
    }
};
struct ReminderCompare {
    bool operator()(const shared_ptr<Note>& a, const shared_ptr<Note>& b) {
        return dateToInt(a->reminder) > dateToInt(b->reminder);
    }
};

// ---------- NoteManager Class ----------
class NoteManager {
private:
    shared_ptr<Note> head;
    shared_ptr<Note> tail;
    int nextId;
    unordered_map<int, shared_ptr<Note>> idMap;
    stack<unique_ptr<Action>> undoStack;
    stack<unique_ptr<Action>> redoStack;
    vector<HistoryEntry> history;
    bool unsavedChanges = false;
    unordered_map<string, vector<shared_ptr<Note>>> keywordIndex;
    priority_queue<shared_ptr<Note>, vector<shared_ptr<Note>>, PriorityCompare> priorityHeap;
    priority_queue<shared_ptr<Note>, vector<shared_ptr<Note>>, ReminderCompare> reminderHeap;

    void indexNote(const shared_ptr<Note>& n) {
        for (const auto& word : splitWords(n->title)) keywordIndex[word].push_back(n);
        for (const auto& word : splitWords(n->content)) keywordIndex[word].push_back(n);
    }
    void rebuildPriorityHeap() {
        priority_queue<shared_ptr<Note>, vector<shared_ptr<Note>>, PriorityCompare> newHeap;
        for (auto temp = head; temp; temp = temp->next.lock()) newHeap.push(temp);
        priorityHeap = move(newHeap);
    }
    void rebuildReminderHeap() {
        priority_queue<shared_ptr<Note>, vector<shared_ptr<Note>>, ReminderCompare> newHeap;
        for (auto temp = head; temp; temp = temp->next.lock())
            if (!temp->reminder.empty()) newHeap.push(temp);
        reminderHeap = move(newHeap);
    }
    void clearKeywordIndex() {
        keywordIndex.clear();
        for (auto temp = head; temp; temp = temp->next.lock()) indexNote(temp);
    }

public:
    NoteManager() : head(nullptr), tail(nullptr), nextId(1) {}
    ~NoteManager() {}

    int getNoteCount() {
        int count = 0;
        for (auto temp = head; temp; temp = temp->next.lock()) count++;
        return count;
    }

    void addNote() {
        string title, content, date, reminder;
        int priority;
        cout << "Enter note title: "; getline(cin, title);
        cout << "Enter note content: "; getline(cin, content);
        while (true) {
            cout << "Enter note priority (1 = High, 2 = Medium, 3 = Low): ";
            string line; getline(cin, line);
            try { priority = stoi(line); if (priority >= 1 && priority <= 3) break; } catch (...) {}
            cout << "Invalid priority! Enter 1, 2, or 3.\n";
        }
        cout << "Enter creation date (DD-MM-YYYY): ";
        getline(cin, date);
        while (!isValidDate(date)) {
            cout << "Invalid date format! Please use DD-MM-YYYY: ";
            getline(cin, date);
        }
        cout << "Set a reminder for this note? (Leave blank to skip): ";
        getline(cin, reminder);

        auto newNote = make_shared<Note>(nextId++, title, content, priority, date, reminder);
        if (!head) {
            head = tail = newNote;
        } else {
            tail->next = newNote;
            newNote->prev = tail;
            tail = newNote;
        }
        idMap[newNote->id] = newNote;
        indexNote(newNote);
        priorityHeap.push(newNote);
        if (!reminder.empty()) reminderHeap.push(newNote);

        auto noteCopy = make_unique<Note>(*newNote);
        undoStack.push(make_unique<Action>(ADD, move(noteCopy), newNote->id));
        while (!redoStack.empty()) redoStack.pop();
        history.push_back({"Created", *newNote, getCurrentTimestamp()});
        unsavedChanges = true;
        cout << "Note added successfully!\n";
    }

    void viewNotes() {
        if (!head) { cout << "No notes available.\n"; return; }
        for (auto temp = head; temp; temp = temp->next.lock()) printNote(temp);
    }

    void printNote(const shared_ptr<Note>& note) {
        cout << "-------------------------\n";
        cout << "ID: " << note->id << endl;
        cout << "Title: " << note->title << endl;
        cout << "Content: " << note->content << endl;
        cout << "Priority: ";
        if (note->priority == 1) cout << "High\n";
        else if (note->priority == 2) cout << "Medium\n";
        else cout << "Low\n";
        cout << "Date: " << note->dateCreated << endl;
        if (!note->reminder.empty())
            cout << "Reminder set for: " << note->reminder << endl;
    }

    void viewNoteById() {
        int id;
        if (!getIntInput("Enter Note ID to view: ", id, 1)) return;
        auto it = idMap.find(id);
        if (it == idMap.end()) { cout << "Note with ID " << id << " not found.\n"; return; }
        printNote(it->second);
    }

    void deleteNote() {
        if (!head) { cout << "No notes to delete.\n"; return; }
        int delId;
        if (!getIntInput("Enter Note ID to delete: ", delId, 1)) return;
        auto it = idMap.find(delId);
        if (it == idMap.end()) { cout << "Note with ID " << delId << " not found.\n"; return; }
        auto temp = it->second;

        string confirm;
        while (true) {
            cout << "Are you sure you want to delete this note? (y/n): ";
            getline(cin, confirm);
            confirm = toLower(confirm);
            if (confirm == "y" || confirm == "yes") break;
            if (confirm == "n" || confirm == "no" || confirm.empty()) {
                cout << "Delete cancelled.\n"; return;
            }
            cout << "Please enter 'y' or 'n'.\n";
        }

        history.push_back({"Deleted", *temp, getCurrentTimestamp()});
        auto noteCopy = make_unique<Note>(*temp);
        undoStack.push(make_unique<Action>(DELETE, move(noteCopy), temp->id));
        while (!redoStack.empty()) redoStack.pop();

        if (temp == head && temp == tail) {
            head = tail = nullptr;
        } else if (temp == head) {
            head = temp->next.lock();
            if (head) head->prev.reset();
        } else if (temp == tail) {
            tail = temp->prev.lock();
            if (tail) tail->next.reset();
        } else {
            auto prev = temp->prev.lock();
            auto next = temp->next.lock();
            if (prev) prev->next = next;
            if (next) next->prev = prev;
        }
        idMap.erase(delId);
        clearKeywordIndex();
        rebuildPriorityHeap();
        rebuildReminderHeap();
        cout << "Note deleted successfully.\n";
        unsavedChanges = true;
    }

    void editNote() {
        if (!head) { cout << "No notes to edit.\n"; return; }
        int editId;
        if (!getIntInput("Enter Note ID to edit: ", editId, 1)) return;
        auto it = idMap.find(editId);
        if (it == idMap.end()) { cout << "Note with ID " << editId << " not found.\n"; return; }
        auto temp = it->second;
        auto prevState = make_unique<Note>(*temp);

        cout << "Enter new title (leave blank to keep old): ";
        string newTitle; getline(cin, newTitle);
        if (!newTitle.empty()) temp->title = newTitle;

        cout << "Enter new content (leave blank to keep old): ";
        string newContent; getline(cin, newContent);
        if (!newContent.empty()) temp->content = newContent;

        cout << "Enter new priority (1-High, 2-Medium, 3-Low) or leave blank: ";
        string priInput; getline(cin, priInput);
        while (!priInput.empty()) {
            try {
                int newPriority = stoi(priInput);
                if (newPriority >= 1 && newPriority <= 3) { temp->priority = newPriority; break; }
            } catch (...) {}
            cout << "Invalid priority! Enter 1, 2, or 3, or leave blank to skip: ";
            getline(cin, priInput);
        }

        cout << "Enter new date (DD-MM-YYYY) or leave blank: ";
        string newDate; getline(cin, newDate);
        while (!newDate.empty() && !isValidDate(newDate)) {
            cout << "Invalid date format! Please use DD-MM-YYYY or leave blank: ";
            getline(cin, newDate);
        }
        if (!newDate.empty()) temp->dateCreated = newDate;

        cout << "Enter new reminder (leave blank to keep old, enter 'none' to remove): ";
        string newReminder; getline(cin, newReminder);
        if (!newReminder.empty()) {
            if (toLower(newReminder) == "none") temp->reminder = "";
            else temp->reminder = newReminder;
        }

        auto afterEdit = make_unique<Note>(*temp);
        undoStack.push(make_unique<Action>(EDIT, move(prevState), temp->id, move(afterEdit)));
        while (!redoStack.empty()) redoStack.pop();
        history.push_back({"Edited", *temp, getCurrentTimestamp()});
        clearKeywordIndex();
        rebuildPriorityHeap();
        rebuildReminderHeap();
        unsavedChanges = true;
        cout << "Note updated successfully.\n";
    }

    void searchNoteByTitle() {
        string keyword;
        cout << "Enter title keyword to search: ";
        getline(cin, keyword);
        string lkey = toLower(keyword);
        if (keywordIndex.count(lkey)) {
            bool found = false;
            for (const auto& n : keywordIndex[lkey]) {
                if (toLower(n->title).find(lkey) != string::npos) { printNote(n); found = true; }
            }
            if (!found) cout << "No note with title containing \"" << keyword << "\" found.\n";
        } else cout << "No note with title containing \"" << keyword << "\" found.\n";
    }
    void searchNoteByContent() {
        string keyword;
        cout << "Enter content keyword to search: ";
        getline(cin, keyword);
        string lkey = toLower(keyword);
        if (keywordIndex.count(lkey)) {
            bool found = false;
            for (const auto& n : keywordIndex[lkey]) {
                if (toLower(n->content).find(lkey) != string::npos) { printNote(n); found = true; }
            }
            if (!found) cout << "No note with content containing \"" << keyword << "\" found.\n";
        } else cout << "No note with content containing \"" << keyword << "\" found.\n";
    }
    void searchNoteByDate() {
        string searchDate;
        cout << "Enter date (DD-MM-YYYY) to search: ";
        getline(cin, searchDate);
        while (!isValidDate(searchDate)) {
            cout << "Invalid date format! Please use DD-MM-YYYY: ";
            getline(cin, searchDate);
        }
        bool found = false;
        for (auto temp = head; temp; temp = temp->next.lock()) {
            if (temp->dateCreated == searchDate) { printNote(temp); found = true; }
        }
        if (!found) cout << "No note with date \"" << searchDate << "\" found.\n";
    }

    void mergeSortNotes(vector<shared_ptr<Note>>& arr, int l, int r, bool byTitle) {
        if (l < r) {
            int m = l + (r-l)/2;
            mergeSortNotes(arr, l, m, byTitle);
            mergeSortNotes(arr, m+1, r, byTitle);
            merge(arr, l, m, r, byTitle);
        }
    }
    void merge(vector<shared_ptr<Note>>& arr, int l, int m, int r, bool byTitle) {
        int n1 = m-l+1, n2 = r-m;
        vector<shared_ptr<Note>> L(arr.begin()+l, arr.begin()+m+1), R(arr.begin()+m+1, arr.begin()+r+1);
        int i=0, j=0, k=l;
        while (i<n1 && j<n2) {
            bool cmp = byTitle ?
                (toLower(L[i]->title) < toLower(R[j]->title))
                : (dateToInt(L[i]->dateCreated) < dateToInt(R[j]->dateCreated));
            if (cmp) arr[k++] = L[i++];
            else arr[k++] = R[j++];
        }
        while (i<n1) arr[k++] = L[i++];
        while (j<n2) arr[k++] = R[j++];
    }
    void sortNotes(int mode) {
        int n = getNoteCount();
        if (n == 0) { cout << "No notes to sort.\n"; return; }
        vector<shared_ptr<Note>> arr;
        for (auto temp = head; temp; temp = temp->next.lock()) arr.push_back(temp);
        if (mode == 1 || mode == 2)
            mergeSortNotes(arr, 0, arr.size()-1, true);
        else
            mergeSortNotes(arr, 0, arr.size()-1, false);
        if (mode == 2 || mode == 3) reverse(arr.begin(), arr.end());
        cout << "\nSorted Notes:\n";
        for (const auto& note : arr) printNote(note);
    }

    void showPriorityNote() {
        if (priorityHeap.empty()) { cout << "No notes in priority queue.\n"; return; }
        printNote(priorityHeap.top());
    }

    void addReminder() {
        int noteId;
        if (!getIntInput("Enter Note ID to set a reminder: ", noteId, 1)) return;
        auto it = idMap.find(noteId);
        if (it == idMap.end()) { cout << "Note not found!\n"; return; }
        auto temp = it->second;
        cout << "Enter reminder (DD-MM-YYYY or description): ";
        string reminder; getline(cin, reminder);
        auto prevState = make_unique<Note>(*temp);
        temp->reminder = reminder;
        auto afterEdit = make_unique<Note>(*temp);
        undoStack.push(make_unique<Action>(EDIT, move(prevState), temp->id, move(afterEdit)));
        while (!redoStack.empty()) redoStack.pop();
        unsavedChanges = true;
        rebuildReminderHeap();
        cout << "Reminder set for Note ID " << noteId << "!\n";
    }
    void viewReminders() {
        cout << "\n--- Reminders Set ---\n";
        bool found = false;
        for (auto temp = head; temp; temp = temp->next.lock()) {
            if (!temp->reminder.empty()) { printNote(temp); found = true; }
        }
        if (!found) cout << "No reminders set for any notes.\n";
    }
    void deleteReminder() {
        int noteId;
        if (!getIntInput("Enter Note ID to delete reminder: ", noteId, 1)) return;
        auto it = idMap.find(noteId);
        if (it == idMap.end()) { cout << "Note not found!\n"; return; }
        auto temp = it->second;
        if (temp->reminder.empty()) { cout << "No reminder set for this note.\n"; return; }
        auto prevState = make_unique<Note>(*temp);
        temp->reminder = "";
        auto afterEdit = make_unique<Note>(*temp);
        undoStack.push(make_unique<Action>(EDIT, move(prevState), temp->id, move(afterEdit)));
        while (!redoStack.empty()) redoStack.pop();
        unsavedChanges = true;
        rebuildReminderHeap();
        cout << "Reminder deleted for Note ID " << noteId << "!\n";
    }

    void undoLastAction() {
        if (undoStack.empty()) { cout << "Nothing to undo!\n"; return; }
        auto action = move(undoStack.top()); undoStack.pop();
        if (action->type == ADD) {
            int id = action->noteId;
            auto it = idMap.find(id);
            if (it != idMap.end()) {
                auto temp = it->second;
                auto copyForRedo = make_unique<Note>(*temp);
                if (temp == head && temp == tail) {
                    head = tail = nullptr;
                } else if (temp == head) {
                    head = temp->next.lock();
                    if (head) head->prev.reset();
                } else if (temp == tail) {
                    tail = temp->prev.lock();
                    if (tail) tail->next.reset();
                } else {
                    auto prev = temp->prev.lock();
                    auto next = temp->next.lock();
                    if (prev) prev->next = next;
                    if (next) next->prev = prev;
                }
                idMap.erase(id);
                clearKeywordIndex(); rebuildPriorityHeap(); rebuildReminderHeap();
                redoStack.push(make_unique<Action>(ADD, move(copyForRedo), id));
            }
            cout << "Undo: Note addition has been undone.\n";
        } else if (action->type == DELETE) {
            auto note = make_shared<Note>(*action->noteCopy);
            if (!head) head = tail = note;
            else {
                tail->next = note;
                note->prev = tail;
                tail = note;
            }
            idMap[note->id] = note;
            clearKeywordIndex(); rebuildPriorityHeap(); rebuildReminderHeap();
            auto copyForRedo = make_unique<Note>(*note);
            redoStack.push(make_unique<Action>(DELETE, move(copyForRedo), note->id));
            cout << "Undo: Note deletion has been undone.\n";
        } else if (action->type == EDIT) {
            int id = action->noteId;
            auto it = idMap.find(id);
            if (it != idMap.end()) {
                auto temp = it->second;
                auto afterEdit = make_unique<Note>(*temp);
                temp->title = action->noteCopy->title;
                temp->content = action->noteCopy->content;
                temp->priority = action->noteCopy->priority;
                temp->dateCreated = action->noteCopy->dateCreated;
                temp->reminder = action->noteCopy->reminder;
                clearKeywordIndex(); rebuildPriorityHeap(); rebuildReminderHeap();
                redoStack.push(make_unique<Action>(EDIT, move(afterEdit), temp->id, make_unique<Note>(*action->noteCopy)));
            }
            cout << "Undo: Note edit has been undone.\n";
        }
        unsavedChanges = true;
    }

    void redoLastAction() {
        if (redoStack.empty()) { cout << "Nothing to redo!\n"; return; }
        auto action = move(redoStack.top()); redoStack.pop();
        if (action->type == ADD) {
            auto note = make_shared<Note>(*action->noteCopy);
            if (!head) head = tail = note;
            else {
                tail->next = note;
                note->prev = tail;
                tail = note;
            }
            idMap[note->id] = note;
            clearKeywordIndex(); rebuildPriorityHeap(); rebuildReminderHeap();
            auto copyForUndo = make_unique<Note>(*note);
            undoStack.push(make_unique<Action>(ADD, move(copyForUndo), note->id));
            cout << "Redo: Note addition has been redone.\n";
        } else if (action->type == DELETE) {
            int id = action->noteId;
            auto it = idMap.find(id);
            if (it != idMap.end()) {
                auto temp = it->second;
                auto copyForUndo = make_unique<Note>(*temp);
                if (temp == head && temp == tail) {
                    head = tail = nullptr;
                } else if (temp == head) {
                    head = temp->next.lock();
                    if (head) head->prev.reset();
                } else if (temp == tail) {
                    tail = temp->prev.lock();
                    if (tail) tail->next.reset();
                } else {
                    auto prev = temp->prev.lock();
                    auto next = temp->next.lock();
                    if (prev) prev->next = next;
                    if (next) next->prev = prev;
                }
                idMap.erase(id);
                clearKeywordIndex(); rebuildPriorityHeap(); rebuildReminderHeap();
                undoStack.push(make_unique<Action>(DELETE, move(copyForUndo), id));
            }
            cout << "Redo: Note deletion has been redone.\n";
        } else if (action->type == EDIT) {
            int id = action->noteId;
            auto it = idMap.find(id);
            if (it != idMap.end() && action->noteAfterEdit) {
                auto temp = it->second;
                auto beforeEdit = make_unique<Note>(*temp);
                temp->title = action->noteAfterEdit->title;
                temp->content = action->noteAfterEdit->content;
                temp->priority = action->noteAfterEdit->priority;
                temp->dateCreated = action->noteAfterEdit->dateCreated;
                temp->reminder = action->noteAfterEdit->reminder;
                clearKeywordIndex(); rebuildPriorityHeap(); rebuildReminderHeap();
                undoStack.push(make_unique<Action>(EDIT, move(beforeEdit), temp->id, make_unique<Note>(*action->noteAfterEdit)));
            }
            cout << "Redo: Note edit has been redone.\n";
        }
        unsavedChanges = true;
    }

    void saveToFile(const string& filename = "notes.txt") {
        ofstream outFile(filename);
        if (!outFile) { cout << "Error opening file for writing.\n"; return; }
        for (auto current = head; current; current = current->next.lock()) {
            outFile << current->id << "\n" << current->title << "\n" << current->content << "\n"
                    << current->priority << "\n" << current->dateCreated << "\n"
                    << current->reminder << "\n----\n";
        }
        outFile.close(); unsavedChanges = false;
        cout << "Notes saved to file successfully!\n";
    }
    void loadFromFile(const string& filename = "notes.txt") {
        string confirm;
        while (true) {
            cout << "Are you sure? Loading will overwrite all current notes. (y/n): ";
            getline(cin, confirm);
            confirm = toLower(confirm);
            if (confirm == "y" || confirm == "yes") break;
            if (confirm == "n" || confirm == "no" || confirm.empty()) {
                cout << "Load cancelled.\n"; return;
            }
            cout << "Please enter 'y' or 'n'.\n";
        }
        ifstream inFile(filename);
        if (!inFile) { cout << "No file found to load notes.\n"; return; }
        head = tail = nullptr; idMap.clear(); nextId = 1;
        string line;
        while (getline(inFile, line)) {
            if (line.empty()) continue;
            int id;
            try { id = stoi(line); } catch (...) { cout << "File format error. Aborting load.\n"; break; }
            string title; getline(inFile, title);
            string content; getline(inFile, content);
            int priority; inFile >> priority; inFile.ignore();
            string date; getline(inFile, date);
            string reminder; getline(inFile, reminder);
            getline(inFile, line);
            if (title.empty() || content.empty() || date.empty() || line != "----") {
                cout << "File format error. Aborting load.\n"; break;
            }
            auto loadedNote = make_shared<Note>(id, title, content, priority, date, reminder);
            if (!head) head = tail = loadedNote;
            else {
                tail->next = loadedNote;
                loadedNote->prev = tail;
                tail = loadedNote;
            }
            idMap[id] = loadedNote;
            nextId = max(nextId, id + 1);
        }
        inFile.close();
        while (!undoStack.empty()) undoStack.pop();
        while (!redoStack.empty()) redoStack.pop();
        history.clear();
        clearKeywordIndex();
        rebuildPriorityHeap();
        rebuildReminderHeap();
        unsavedChanges = false;
        cout << "Notes loaded successfully from file!\n";
    }
    void viewHistory() {
        if (history.empty()) { cout << "No history available.\n"; return; }
        cout << "\n--- Note History ---\n";
        int i = 1;
        for (const auto& entry : history) {
            cout << i++ << ". Action: " << entry.action << " | Note ID: " << entry.noteSnapshot.id
                 << " | Title: " << entry.noteSnapshot.title << " | Timestamp: " << entry.timestamp << endl;
        }
    }
    void viewHistoryDetail() {
        if (history.empty()) { cout << "No history available.\n"; return; }
        cout << "\n--- Note History Details ---\n";
        int idx;
        if (!getIntInput("Enter history entry number for details: ", idx, 1, (int)history.size()))
            return;
        const auto& entry = history[idx-1];
        cout << "Action: " << entry.action << "\nTimestamp: " << entry.timestamp << endl;
        cout << "Note Details:\n";
        auto note = make_shared<Note>(entry.noteSnapshot);
        printNote(note);
    }

    bool hasUnsavedChanges() const { return unsavedChanges; }
    void setUnsavedChanges(bool v) { unsavedChanges = v; }
};

// ---------- Menu & Main ----------
enum MenuReturn { STAY, MAINMENU };
void showHelp() {
    cout << "\n--- Help / About ---\n";
    cout << "Smart Notes Organizer - CLI Edition\n";
    cout << "- Use the menu options to create, edit, search, and manage your notes.\n";
    cout << "- Dates must be in DD-MM-YYYY format.\n";
    cout << "- Reminders are informational only.\n";
    cout << "- Undo/Redo stack is unlimited in size this session.\n";
    cout << "- You must save your notes to file to persist them between runs.\n";
    cout << "- For more info, read documentation or contact support.\n";
}
MenuReturn notesMenu(NoteManager& manager) {
    while (true) {
        cout << "\n--- Notes Menu ---\n";
        cout << "1. Add Note\n2. View All Notes\n3. View Note by ID\n4. Edit Note\n5. Delete Note\n0. Back to Main Menu\n";
        cout << "Enter choice: ";
        string line; getline(cin, line); int choice;
        try { choice = stoi(line); } catch (...) { choice = -1; }
        switch (choice) {
            case 1: manager.addNote(); break;
            case 2: manager.viewNotes(); break;
            case 3: manager.viewNoteById(); break;
            case 4: manager.editNote(); break;
            case 5: manager.deleteNote(); break;
            case 0: return MAINMENU;
            default: cout << "Invalid choice!\n";
        }
    }
}
MenuReturn searchMenu(NoteManager& manager) {
    while (true) {
        cout << "\n--- Search Menu ---\n";
        cout << "1. Search by Title\n2. Search by Content\n3. Search by Date\n0. Back to Main Menu\n";
        cout << "Enter choice: ";
        string line; getline(cin, line); int choice;
        try { choice = stoi(line); } catch (...) { choice = -1; }
        switch(choice) {
            case 1: manager.searchNoteByTitle(); break;
            case 2: manager.searchNoteByContent(); break;
            case 3: manager.searchNoteByDate(); break;
            case 0: return MAINMENU;
            default: cout << "Invalid choice!\n";
        }
    }
}
MenuReturn sortNotesMenu(NoteManager& manager) {
    while (true) {
        cout << "\n--- Sort Notes Menu ---\n";
        cout << "1. By Title (A-Z)\n2. By Title (Z-A)\n3. By Date (Newest First)\n4. By Date (Oldest First)\n0. Back to Main Menu\n";
        cout << "Enter choice: ";
        string line; getline(cin, line); int choice;
        try { choice = stoi(line); } catch (...) { choice = -1; }
        if (choice >= 1 && choice <= 4)
            manager.sortNotes(choice);
        else if (choice == 0) return MAINMENU;
        else cout << "Invalid choice!\n";
    }
}
MenuReturn remindersMenu(NoteManager& manager) {
    while (true) {
        cout << "\n--- Reminders Menu ---\n";
        cout << "1. Add Reminder\n2. View Reminders\n3. Delete Reminder\n0. Back to Main Menu\n";
        cout << "Enter choice: ";
        string line; getline(cin, line); int choice;
        try { choice = stoi(line); } catch (...) { choice = -1; }
        switch (choice) {
            case 1: manager.addReminder(); break;
            case 2: manager.viewReminders(); break;
            case 3: manager.deleteReminder(); break;
            case 0: return MAINMENU;
            default: cout << "Invalid choice!\n";
        }
    }
}
MenuReturn fileOperationsMenu(NoteManager& manager) {
    while (true) {
        cout << "\n--- File Operations Menu ---\n";
        cout << "1. Save Notes to File\n2. Load Notes from File\n0. Back to Main Menu\n";
        cout << "Enter choice: ";
        string line; getline(cin, line); int choice;
        try { choice = stoi(line); } catch (...) { choice = -1; }
        switch (choice) {
            case 1: manager.saveToFile(); break;
            case 2: manager.loadFromFile(); break;
            case 0: return MAINMENU;
            default: cout << "Invalid choice!\n";
        }
    }
}
MenuReturn historyMenu(NoteManager& manager) {
    while (true) {
        cout << "\n--- History Menu ---\n";
        cout << "1. View Note History (List)\n2. View History Entry Details\n0. Back to Main Menu\n";
        cout << "Enter choice: ";
        string line; getline(cin, line); int choice;
        try { choice = stoi(line); } catch (...) { choice = -1; }
        switch (choice) {
            case 1: manager.viewHistory(); break;
            case 2: manager.viewHistoryDetail(); break;
            case 0: return MAINMENU;
            default: cout << "Invalid choice!\n";
        }
    }
}

int main() {
    NoteManager manager;
    string line;
    int choice;
    while (true) {
        cout << "\n===== Smart Notes Organizer =====\n";
        cout << "1. Notes\n2. Search\n3. Sort Notes\n4. Reminders\n5. File Operations\n6. Undo Last Action\n7. Redo Last Action\n8. History\n9. Help/About\n10. Show Highest Priority Note\n0. Exit\n";
        cout << "Enter choice: ";
        getline(cin, line);
        try { choice = stoi(line); } catch (...) { choice = -1; }
        MenuReturn ret = STAY;
        if (choice == 0) {
            if (manager.hasUnsavedChanges()) {
                string confirm;
                while (true) {
                    cout << "You have unsaved changes. Are you sure you want to exit? (y/n): ";
                    getline(cin, confirm);
                    confirm = toLower(confirm);
                    if (confirm == "y" || confirm == "yes") break;
                    if (confirm == "n" || confirm == "no" || confirm.empty()) goto skip_exit;
                    cout << "Please enter 'y' or 'n'.\n";
                }
            }
            cout << "Exiting safely...\n";
            return 0;
        }
        switch (choice) {
            case 1: ret = notesMenu(manager); break;
            case 2: ret = searchMenu(manager); break;
            case 3: ret = sortNotesMenu(manager); break;
            case 4: ret = remindersMenu(manager); break;
            case 5: ret = fileOperationsMenu(manager); break;
            case 6: manager.undoLastAction(); break;
            case 7: manager.redoLastAction(); break;
            case 8: ret = historyMenu(manager); break;
            case 9: showHelp(); break;
            case 10: manager.showPriorityNote(); break;
            default: cout << "Invalid choice!\n";
        }
        if (ret == MAINMENU) continue;
    skip_exit:
        ;
    }
}